Request.Form记录了前端发送给服务器的 表单 ，作用类似于 php 中的 $_GET $_POST
类型是NameValueCollection 键值对集合 也可以获取枚举器什么的

Request中也定义了其他相关的数据类型，比如Headers之类的
