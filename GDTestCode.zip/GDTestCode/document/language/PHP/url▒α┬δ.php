<?php
urlencode($str);
urldecode($str);
//如果通过get方式发送请求，一定不要忘掉这个，否则有可能会出现很奇怪的错误，在有些机器上
?>