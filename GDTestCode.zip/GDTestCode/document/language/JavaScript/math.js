//Math对象用来执行常见的算术任务
Math.random();

round() 
//如何使用 round()。 
random() 
//如何使用 random() 来返回 0 到 1 之间的随机数。 
max() 
//如何使用 max() 来返回两个给定的数中的较大的数。 
min() 
//如何使用 min() 来返回两个给定的数中的较小的数。 