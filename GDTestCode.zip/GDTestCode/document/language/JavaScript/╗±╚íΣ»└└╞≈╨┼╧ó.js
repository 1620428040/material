document.write("<table>");
document.write("<tr><td>浏览器的代码名:</td><td>"+navigator.appCodeName+"</td></tr>");
document.write("<tr><td>浏览器的次级版本:</td><td>"+navigator.appMinorVersion+"</td></tr>");
document.write("<tr><td>浏览器的名称:</td><td>"+navigator.appName+"</td></tr>");
document.write("<tr><td>浏览器的平台和版本信息:</td><td>"+navigator.appVersion+"</td></tr>");
document.write("<tr><td>浏览器的语言:</td><td>"+navigator.browserLanguage+"</td></tr>");
document.write("<tr><td>是否启用cookie:</td><td>"+navigator.cookieEnabled+"</td></tr>");
document.write("<tr><td>系统的CPU等级:</td><td>"+navigator.cpuClass+"</td></tr>");
document.write("<tr><td>是否处于脱机模式:</td><td>"+navigator.onLine+"</td></tr>");
document.write("<tr><td>操作系统平台:</td><td>"+navigator.platform+"</td></tr>");
document.write("<tr><td>系统默认语言:</td><td>"+navigator.systemLanguage+"</td></tr>");
document.write("<tr><td>UA标识:</td><td>"+navigator.userAgent+"</td></tr>");
document.write("<tr><td>系统自然语言设置:</td><td>"+navigator.userLanguage+"</td></tr>");
document.write("</table>");

