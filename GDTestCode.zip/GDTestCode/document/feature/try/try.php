<?php
try{
	
}
catch(Exception $exec){

}

?>