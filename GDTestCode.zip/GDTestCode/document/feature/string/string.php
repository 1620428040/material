<?php
explode($delimiter, $string);//用给出的字符串切割字符串
str_split($string,10);//将字符串按字符个数分隔成数组(-1 /2 ?)
?>