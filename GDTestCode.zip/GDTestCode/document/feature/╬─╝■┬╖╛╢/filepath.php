<?php
//中文字符的支持有问题，路径中不要出现中文！！！


//文件路径的正确写法
"C:\\Users\\admin\\Desktop\\ww.txt"

//或者
"C:/Users/admin/Desktop/ww.txt"

//如果不会出现会被认为是转义字符的字符串，这样写也可以
"C:\Users\admin\Desktop\ww.txt"
?>