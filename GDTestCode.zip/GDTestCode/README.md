# GDTestCode
###关于网站的前端和后端的代码
###tools		一些函数，类什么的，可以直接复制到项目里使用
###document		使用HTML，CSS，JavaScript，PHP，ASP.net这些语言时，记录下的文档。不包括各种框架的文档
###framework	对各种框架的使用，修改，记下来的文档，之类的东西
###sometest		各种突发奇想的测试